/*
    COMP 348 - Programming Languages
    Assignment 1 - Due June 5th 2023 @ midnight 
    Naika Jean-Baptiste (40227367)
*/
double aggregrate(const char* func, double* arr,int size);//"const char* func" ==> pointer to constant
